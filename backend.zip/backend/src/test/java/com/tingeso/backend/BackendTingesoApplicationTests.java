package com.tingeso.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendTingesoApplicationTests {

	@Test
	void contextLoads() {
	}

}
