package com.tingeso.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTingesoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendTingesoApplication.class, args);
	}

}
